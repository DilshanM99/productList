// import React, { useEffect, useState } from "react";
// import ProductCard from "../productCard/ProductCard";
// import styles from "./Products.module.css";

// function Products() {
//   const [data, setData] = useState([]);
//   const getData = () => {
//     fetch("products.json") //, {
//       // headers: {
//       //   "Content-Type": "application/json",
//       //   Accept: "application/json",
//       // },
//     // })
//       .then((response) => {
//         return response.json();
//       })
//       .then((myJson) => {
//         setData(myJson);
//       });
//   };

//   useEffect(() => {
//     getData();
//   }, []);

//   return (
//     <div className={styles.container}>
//       {data &&
//         data.length > 0 &&
//         data.map((product, id) => {
//           return <ProductCard key={id} product={product} />;
//         })}
//     </div>
//   );
// }

// export default Products;

import React, { useEffect, useState, useRef } from "react";
import ProductCard from "../productCard/ProductCard";
import styles from "./Products.module.css";

function Products() {
  const [data, setData] = useState([]);
  const [visibleData, setVisibleData] = useState([]);
  const [startIndex, setStartIndex] = useState(0);
  const containerRef = useRef(null);


  const fetchData = () => {
    fetch("products.json")
      .then((response) => response.json())
      .then((data) => {
        setData(data);
        setVisibleData(data.slice(0, 8));
      })
      .catch((error) => console.error("Error fetching data:", error));
  };
  

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const newStartIndex = startIndex + 4;
            if (newStartIndex < data.length) {
              setVisibleData((prevData) => [
                ...prevData,
                ...data.slice(newStartIndex, newStartIndex + 4)
              ]);
              setStartIndex(newStartIndex);
            }
          }
        });
      },
      { root: null, rootMargin: "0px", threshold: 0.5 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, [startIndex, data]);

  return (
    <div className={styles.container}>
      {visibleData.map((product, id) => (
        <ProductCard key={id} product={product} />
      ))}
      <div ref={containerRef} style={{ height: "20px" }} />
    </div>
  );
}

export default Products;

