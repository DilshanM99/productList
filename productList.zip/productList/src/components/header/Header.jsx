import React from 'react';
import './Header.css';

function Header() {
  return (
    <div className='container'>
      <h1 className='header'>Product List</h1>
    </div>
  )
}

export default Header
